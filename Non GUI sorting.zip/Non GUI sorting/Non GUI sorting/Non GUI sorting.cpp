#include <chrono>
#include <fstream>
#include <iostream>
#include <random>
#include <string>
#include <thread>
#include <vector>
#include <ctime>
using namespace std;
//^prelim stuff

void randomizer();
void sorter1(vector<float>); // declaring functions

int main()

{
	while (true) {
		string hasFile;
		string fileName;
		string done;

		cout << "Do you have your own file?\n";
		cin >> hasFile;

		if (hasFile != "yes") { // if you dont have a file it gives you

			randomizer();
			fileName = "unsorted.txt";

		}
		else {

			cout << "Whats it called" << endl;
			cin >> fileName; // getting a name to add to
		}

		ifstream unsortedFile(fileName); // nabs the file


		string unsortedString;
		// int counter = 0;
		vector<float> unsortedVector; // this gets sorted

		while (getline(unsortedFile, unsortedString)) {
			unsortedVector.push_back(stof(unsortedString)); // puts file
			// cout << unsortedVector[counter] << endl;     //on vector
			// counter++;
		}

		int algchoice;
		cout << "What sorting algorithm do you want?" << endl;
		cout << "1. My fucking best" << endl;
		cin >> algchoice;
		cout << endl;

		// this here lets you choose what sorting algorithm you want
		switch (algchoice) {

		case 1:
			sorter1(unsortedVector);
			cout << endl << "are you done?" << endl;
			cin >> done;
			if (done == "yes") {
				goto exit_loop;
			}
			break;

		default:
			break;
		}
	}
exit_loop:;
}
void randomizer() {
	int numnum;
	int range;
	cout << "How many numbers do you want to sort?\n";
	cin >> numnum;
	cout << "Max number?\n"; // takes "parameters" to randomize
	cin >> range;
	random_device rd;
	default_random_engine gen(rd());
	uniform_int_distribution<int> distribution(1, range);
	ofstream unsortedFile("unsorted.txt");
	for (int i = 0; i < numnum; i++) {
		int rand = distribution(gen);                     // rerolling every loop
		cout << endl << rand;                             // prints it as proof
		unsortedFile << rand << endl;                     // writes it to file
		this_thread::sleep_for(chrono::milliseconds(10)); // spam=cool
	}
	cout << endl << endl; // some effects
	cout << "Starting Sort:" << endl << endl;
}

void sorter1(vector<float> unsortedVector) {
	bool Finished = false;
	string debugMode;
	// bool sameIndex2;
	int index = 0;
	int index2 = 0;
	int tempMaxIndex{};

	// places the first number
	vector<float> sorted(unsortedVector.size()); // we sort to this
	vector<bool> used(unsortedVector.size());  // notes used
	//  high numbers

	cout << "debug mode?" << endl;
	cin >> debugMode;
	cout << endl;
	//auto timeStart = chrono::steady_clock::now();;



	while (!Finished) {

		if (sorted[index2] < unsortedVector[index] && !used[index]) {

			sorted[index2] = unsortedVector[index];

			tempMaxIndex = index;
			if (debugMode == "yes") {
				cout << endl << "this is at index:" << index << endl;
				cout << "this is at index2:" << index2 << endl;
			}
		}

		if (index2 == unsortedVector.size() - 1) {

			Finished = true;
			for (int k = 0; k < sorted.size() - 1; k++) {
				cout << sorted[k] << endl;
			}
			if (debugMode == "yes") {
				cout << endl << "this is sorted size " << sorted.size();
				cout << endl
					<< "this is unsorted size " << unsortedVector.size() << endl;

				for (int z = 0; z < used.size(); z++) {
					cout << "this index is " << boolalpha;
					cout << used[z] << endl;
				}
			}
		}
		if (index == unsortedVector.size() - 1) {
			index = 0;
			used[tempMaxIndex] = true;
			index2++;

		}
		else {
			index++;
		}
	}
	//auto timeEnd = chrono::steady_clock::now();
	//chrono::milliseconds time = timeEnd-timeStart;
	//cout << "Time Elapsed:";
	//get time here
}
